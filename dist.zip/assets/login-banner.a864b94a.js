const n=""+new URL("login-banner.426fb77f.png",import.meta.url).href;export{n as b};
