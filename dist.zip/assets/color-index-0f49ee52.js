const r=["orangered","green","red","cyan","blue","arcoblue","purple","pinkpurple","magenta","gray"],n=e=>(e%=r.length,r[e]);export{n as g};
