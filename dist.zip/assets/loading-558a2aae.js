import{z as a}from"./arco-36de679c.js";function l(e=!1){const o=a(e);return{loading:o,setLoading:t=>{o.value=t},toggle:()=>{o.value=!o.value}}}export{l as u};
