import{e as a}from"./arco.d57277c9.js";function l(o=!1){const e=a(o);return{loading:e,setLoading:t=>{e.value=t},toggle:()=>{e.value=!e.value}}}export{l as u};
