const s="driver-v2.2.0",S="successUpdataUserSelfInfo-v2.2.0";export{S as F,s as a};
