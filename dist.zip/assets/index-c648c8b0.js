import{Q as c,h as t}from"./arco-36de679c.js";function s(n,i){const o=c(`${n.icon}`);return t(o)}const e=s,r=e;export{r as F};
